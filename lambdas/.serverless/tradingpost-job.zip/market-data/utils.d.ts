export declare const buildGroups: (securities: any[], max?: number) => any[][];
